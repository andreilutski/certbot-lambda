"""Internal implementation of `~certbot_dns_route53.dns_route53` plugin."""
